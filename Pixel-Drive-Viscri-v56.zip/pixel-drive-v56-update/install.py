#!/usr/bin/env python3
"""Validate ALL files before applying the incremental v55 -> v56 update."""
import argparse,datetime,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--apply',action='store_true');args=ap.parse_args()
root=Path.cwd().resolve();package=Path(__file__).resolve().parent
run=lambda *a:subprocess.check_output(['git',*a],cwd=root,text=True).strip()
if Path(run('rev-parse','--show-toplevel')).resolve()!=root:sys.exit('Run this installer from the repository root.')
if run('diff','--cached','--name-only'):sys.exit('There are already staged changes. Commit or unstage them before installing v56.')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
manifest=json.loads((package/'manifest.json').read_text());pending=[]
for item in manifest:
 rel=Path(item['path'])
 if rel.is_absolute() or '..' in rel.parts:sys.exit('Invalid package path')
 target=root/rel;source=package/'files'/rel
 if target.is_symlink() or not target.resolve().is_relative_to(root):sys.exit('Refusing linked target: '+str(rel))
 if sha(source)!=item['after']:sys.exit('Corrupt payload: '+str(rel))
 current=sha(target)
 if current==item['after']:continue
 if current!=item['before']:sys.exit('STOP: newer or modified file: '+str(rel)+'; nothing has been installed.')
 pending.append((rel,target,source))
print('Validated',len(manifest),'files;',len(pending),'updates required.')
if not args.apply:
 print('Validation only. Add --apply to install.');sys.exit(0)
if not pending:sys.exit(0)
gitdir=Path(run('rev-parse','--absolute-git-dir'));backup=gitdir/'pixel-drive-v56-backups'/datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f')
backup.mkdir(parents=True);written=[]
try:
 for rel,target,source in pending:
  existed=target.exists()
  if existed:
   b=backup/rel;b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,b)
  written.append((rel,target,existed));target.parent.mkdir(parents=True,exist_ok=True)
  temporary=target.with_name(target.name+'.v56-tmp');shutil.copyfile(source,temporary);os.replace(temporary,target)
except Exception:
 for rel,target,existed in reversed(written):
  if existed:shutil.copy2(backup/rel,target)
  else:target.unlink(missing_ok=True)
 raise
print('v56 installed. Backups:',backup)
