# Pixel Drive

Buildless browser driving game. Serve `dist/`; the main level is `/nivel-1/`.

## Controls
W accelerates; S brakes then reverses; A/D steer continuously while moving; Space brakes; Q/E toggle indicators; P pauses. Touch controls use pointer capture and clear held inputs on cancellation or lost focus.

## Source organization
- `world.js`: 112 × 112 world, road geometry, 49 junctions, signs, signal timing.
- `rules.js`: contextual Romanian learning panel and official legal references.
- `simulation.js`: player motion, AI traffic, pedestrian crossings, collision and rule scoring.
- `render.js`: cached neighborhood art, dynamic vehicles, signs, signals, pedestrians, minimap.
- `joc.js`: input, UI and animation loop.
- `drive.css`: level-specific responsive UI.

The traffic simulation is educational and simplified. It is not a driving exam or a complete implementation of traffic legislation. Scoring is a game mechanic, not a legal penalty. NPCs pick routes at junctions; roundabout traffic uses a single lane. General right priority is used on equal-category uncontrolled roads in this fictional map.

Run `node tests/simulation.cjs` from the project root. It checks high-refresh-rate movement, continuous steering, brakes/pause, fail conditions, red/STOP/right-priority penalties, all NPC turn paths and a two-minute traffic/pedestrian simulation.
