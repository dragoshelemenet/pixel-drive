PIXEL DRIVE - 1-MINUTE QUIZ COUNTDOWN (v4)

This patch changes ONLY the 2 files below:
  dist/nivel-1/index.html
  dist/nivel-1/timed-quiz.js

Normal Level 1 (/nivel-1/) automatically shows a 01:00 countdown and opens one image-based quiz every 60 seconds of active gameplay. Correct: +50 CR; incorrect: 0 CR. Pauses while answering, game paused, or another dialog is open. Restarts after answering.

Optional /nivel-1/?quizTest=1 remains 10-second debug-only mode.

HOW TO INSTALL IN CODESPACES
Upload ZIP to repository ROOT, then run:

  git pull
  unzip -o Pixel-Drive-Quiz-1-Minute-Default.zip -d .
  git add dist/nivel-1/index.html dist/nivel-1/timed-quiz.js
  git commit -m "Use 1-minute driving quizzes by default"
  git push origin main

If a web server is already running, hard refresh the game tab. Otherwise start:

  python3 -m http.server 8000 --bind 0.0.0.0 --directory dist

Open the Codespaces forwarded port 8000 and click Level 1 (or visit /nivel-1/). No query string needed.
Do not re-extract the original Pixel-Drive.zip after this patch.
