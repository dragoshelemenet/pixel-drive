Pixel Drive quiz v38 - default 60 seconds.

Extract into repository root after pulling. No original game ZIP extraction after the update.
Normal Level 1: /nivel-1/
Every 60s of active gameplay, an image-based question opens automatically.
Correct = +50 credits; incorrect = +0.
The old ?quizTest=1 URL no longer reduces the timer to 10s.

Upload and install:
  unzip -o Pixel-Drive-Quiz-Fix-v38.zip -d .
  git add dist/nivel-1/index.html dist/nivel-1/timed-quiz.js
  git commit -m "Fix default quiz timer to always be 60 seconds"
  git push origin main

Start server: python3 -m http.server 8000 --bind 0.0.0.0 --directory dist
