PIXEL DRIVE — QUIZ UPDATE (PATCH ONLY)
====================================
This ZIP contains ONLY updated/new files, no 3D models or original game assets.

Files inside:
- dist/nivel-1/index.html (load new scripts)
- dist/nivel-1/drive.css (quiz styles)
- dist/nivel-1/career.js (driving-school quizzes, add credits)
- dist/nivel-1/quiz-bank.js (3 extensible questions)
- dist/nivel-1/timed-quiz.js (2-minute driving timer + popup)

CODESPACES — upload this ZIP to your repo root, then run:

    git pull && unzip -o Pixel-Drive-Quiz-Update.zip -d .
    git add dist/nivel-1 && git commit -m "Add road quizzes and 2-minute driving challenge" && git push

If the server is already running on 8000, simply refresh your game browser tab.
If it is not running, use:

    python3 -m http.server 8000 --bind 0.0.0.0 --directory dist

Normal URL: /nivel-1/ (timer 02:00, counts only while the car moves)
Quick-test URL: /nivel-1/?quizTest=1 (timer 00:10 while driving)

Driving questions: +50 credits on correct answer, +0 otherwise; no penalty.
Driving-school quiz: 3 questions, 2/3 to pass, +150 credits; repeatable.
Countdown pauses while the game is paused or while answering the question.

To add questions later: edit dist/nivel-1/quiz-bank.js; keep id unique, and
use correct: 0, 1, or 2 for the right answer index.
This small starter set is grounded in Romanian traffic law, not a copied DRPCIV exam bank.
