/* CPU integration regression; real geometry, stubbed DOM. */
const {context}=require('./game-context.cjs');
const assert=require('assert');
for(const city of ['viscri','original']){
 const c=context(city);for(const f of ['maps/viscri-data','maps/service-layout','maps/road-safety','maps/viscri-world','world','rules','simulation'])c.load(f);
 const W=c.DriveWorld,S=c.DriveSimulation;
 assert.equal(!!W.realMap,city==='viscri');
 if(W.realMap){assert.equal(W.buildings.length,449);assert(W.realTrafficRoutes.length>5);
 for(const r of W.roads){const length=ps=>ps.slice(1).reduce((sum,p,i)=>sum+Math.hypot(p[0]-ps[i][0],p[1]-ps[i][1]),0);assert(Math.abs(length(r.points)-r.parts.reduce((sum,p)=>sum+length(p),0))<1e-6,'road continuity '+r.id);}
 for(const p of W.services){assert(W.roadAt(p.x,p.z,.1),'service accessible '+p.type);if(p.site){const s=p.site;for(let x=-s.access+.1;x<=3.8;x+=.15)assert(W.roadAt(s.x+s.ux*x*(s.scale||1),s.z+s.uz*x*(s.scale||1),.05),'driveway gap '+p.type);assert(!W.roadAt(s.x+s.ux*7*(s.scale||1),s.z+s.uz*7*(s.scale||1)),'shop interior must not be drivable');}}
 const a=W.trainingAccess.a,b=W.trainingAccess.b;for(let t=0;t<=1;t+=.025)assert(W.roadAt(a.x+(b.x-a.x)*t,a.z+(b.z-a.z)*t,.05),'training access gap');
 }
 if(W.realMap){
  // Sample the actual rendered bend triangles, rather than just centrelines.
  let roadSamples=0;
  for(const r of W.roads)for(let i=1;i<r.points.length;i++){
   const a=r.points[i-1],b=r.points[i],na=r.normals[i-1],nb=r.normals[i],h=(r.width+.14)/2;
   const ps=[[a[0]+na[0]*h,a[1]+na[1]*h],[a[0]-na[0]*h,a[1]-na[1]*h],[b[0]+nb[0]*h,b[1]+nb[1]*h],[b[0]-nb[0]*h,b[1]-nb[1]*h]];
   for(const ids of [[0,2,1],[1,2,3]])for(const weights of [[.8,.1,.1],[.1,.8,.1],[.1,.1,.8],[1/3,1/3,1/3]]){
    const x=ids.reduce((n,id,k)=>n+ps[id][0]*weights[k],0),z=ids.reduce((n,id,k)=>n+ps[id][1]*weights[k],0);
    assert(W.roadAt(x,z,.02),'rendered road rejected at '+r.id);roadSamples++;
   }
  }
  assert(!W.roadAt(-100,-100),'off-map terrain must stay blocked');console.log(JSON.stringify({roadSamples,checks:'render/collision agreement passed'}));
  assert.equal(W.vehicleScale,.67);assert.equal(W.serviceScale,.5);
  assert(W.signs.length>0);assert(W.signs.every(q=>['way-maxspeed','virtual-service-exit'].includes(q.source)&&q.surveyed===false));
  for(const q of W.signs.filter(q=>q.source==='way-maxspeed'))assert(q.reason==='map-entry'||q.previousLimits.some(n=>n!==Number(q.kind.slice(5))),'speed board requires an actual limit change');
  assert(W.yieldApproaches.length>0,'virtual exits need yield boards');
  for(const q of W.yieldApproaches){const s=S.create(),site=q.site,point=x=>({x:site.x+site.ux*x,z:site.z+site.uz*x});
   const old=point(-.1);Object.assign(s.player,point(-.15),{angle:q.angle,speed:.3});
   const n=W.nearestRoad(q.exit),v=n.tangent;s.traffic=[{x:q.exit.x-v.x*2,z:q.exit.z-v.z*2,angle:Math.atan2(v.z,v.x),speed:.5}];S.checkRules(s,old);assert(s.violationEvent?.key.startsWith('yield-exit-'),'traffic approaching virtual exit requires yield');
   s.violationEvent=null;s.ruleCooldown={};s.traffic=[];S.checkRules(s,old);assert(!s.violationEvent,'empty exit must not penalize');
  }

  for(const q of W.signs)for(const r of W.roads)for(const part of r.parts){const a=part[0],b=part[1],dx=b[0]-a[0],dz=b[1]-a[1],len2=dx*dx+dz*dz,t=Math.max(0,Math.min(1,((q.x-a[0])*dx+(q.z-a[1])*dz)/len2));assert(Math.hypot(q.x-a[0]-dx*t,q.z-a[1]-dz*t)>r.width/2,'sign intersects road '+q.id);}
  const a=S.vehicleBody({x:0,z:0,angle:0}),b=S.vehicleBody({x:0,z:.52,angle:Math.PI});assert(!S.bodiesOverlap(a,b),'opposite lanes must not collide');b.z=.1;assert(S.bodiesOverlap(a,b),'actual vehicle contact must collide');
  const saved=W.landmarks;W.landmarks=[{kind:'museum',x:10,z:10},{kind:'parking',x:11,z:10}];assert.equal(c.DriveRules.context({player:{x:10,z:10,angle:0},pedestrians:[],time:0}).key,'parking');W.landmarks=saved;
 }
 // Drive from every launch position, for every purchasable body size.
 if(W.realMap){
  for(let model=0;model<4;model++)for(let attempt=0;attempt<=W.scenarios.length;attempt++){
   c.DriveCareer={model:()=>model};c.store.set('pixel-route-attempt-viscri',String(attempt-1));
   const s=S.create({vary:attempt>0}),start={...s.player};
   for(let frame=0;frame<180;frame++)S.update(s,{w:true},1/60);
   assert.equal(s.collisions,0,'launch collision model '+model+' start '+attempt);
   assert(Math.hypot(s.player.x-start.x,s.player.z-start.z)>.9,'launch must move model '+model+' start '+attempt);
  }
  delete c.DriveCareer;
 }
 // Exercise the real public capture -> interrupt -> retry path, including cyclic topology.
 c.load('replay-training');const replayState=S.create(),actor=replayState.traffic[0],route=actor.route,j=actor.j;
 c.DriveReplay.onFrame(replayState,{},10000);
 const originalX=actor.x;actor.x+=1;
 replayState.violationEvent={id:1,key:'test',kind:'speed',direction:null,junctionId:null,limit:50,speedKmh:70,player:{...replayState.player}};
 c.DriveReplay.onFrame(replayState,{},10300);assert(c.DriveReplay.open());
 c.elements.find(e=>e.id==='driving-replay').querySelector('#dr-retry').onclick();
 assert(!c.DriveReplay.open());assert(!replayState.paused);assert.equal(replayState.traffic[0].x,originalX);assert.equal(replayState.traffic[0].j,j);if(route)assert.equal(replayState.traffic[0].route,route);
 S.update(replayState,{},.016);
 if(W.realMap){
  let retries=0;
  // Start the public replay flow with a failed checkpoint inside real footprints.
  for(const building of W.buildings.filter((_,i)=>i%8===0)){
   c.DriveCareer={model:()=>retries%4};
   const ps=building.points,p={x:ps.reduce((n,p)=>n+p[0],0)/ps.length,z:ps.reduce((n,p)=>n+p[1],0)/ps.length,angle:Math.PI/3,speed:0,indicator:0};
   const s=S.create();s.traffic=[];s.pedestrians=[];s.player=p;s.collisions=4;s.failed=true;
   c.DriveReplay.onFrame(s,{},12000+retries*1000);
   s.violationEvent={id:10+retries,key:'collision',kind:'collision',direction:1,junctionId:W.junctions[retries%W.junctions.length].id,limit:50,player:{...p}};
   c.DriveReplay.onFrame(s,{},12300+retries*1000);assert(c.DriveReplay.open());c.elements.find(e=>e.id==='driving-replay').querySelector('#dr-retry').onclick();
   assert(W.poseFits(s.player,s.traffic,1.6),'retry must leave a clear launch corridor');const start={...s.player},count=s.collisions;
   for(let k=0;k<180;k++)S.update(s,{w:true},1/60);
   assert.equal(s.collisions,count,'retry must not immediately collide');assert(!s.failed);assert(Math.hypot(s.player.x-start.x,s.player.z-start.z)>.9);retries++;
  }
  delete c.DriveCareer;
  let missions=0;const mission=S.create();mission.traffic=[];mission.pedestrians=[];
  for(const id of ['pickup','dropoff','parking']){const target=W.landmarks.find(l=>l.id===id);assert(W.poseFits(target,[],1.6));assert(!W.roadAt(target.passenger.x,target.passenger.z));assert(!W.obstacleAt(target.passenger));assert(W.connectedRoads.has(W.roads.find(r=>r.id===target.roadId)));
   Object.assign(mission.player,target,{x:target.x-Math.cos(target.angle),z:target.z-Math.sin(target.angle),speed:0});const count=mission.collisions;
   for(let k=0;k<180;k++)S.update(mission,{w:true},1/60);mission.player.speed=0;
   assert.equal(mission.collisions,count);assert.equal(S.interact(mission)?.type,'mission');missions++;
   const route=W.routeRoad(W.playerStart,target);assert(route.length>1,'road route must reach mission');
   for(let i=1;i<route.length;i++){const a=route[i-1],b=route[i],len=Math.hypot(b.x-a.x,b.z-a.z);for(let d=0;d<len;d+=.2)assert(!W.obstacleAt({x:a.x+(b.x-a.x)*d/len,z:a.z+(b.z-a.z)*d/len,angle:Math.atan2(b.z-a.z,b.x-a.x)}),'route must clear actual buildings');}
   for(let i=1;i<route.length;i++)for(let t=0;t<=1;t+=.1)assert(W.roadAt(route[i-1].x+(route[i].x-route[i-1].x)*t,route[i-1].z+(route[i].z-route[i-1].z)*t),'navigation must follow road, not chords through houses');
  }
  console.log(JSON.stringify({safeRetries:retries,missionApproaches:missions,signs:W.signs.length,yieldExits:W.yieldApproaches.length}));
 }

 let s=S.create();s.pedestrians=[];
 if(W.realMap){s.player.x=10;s.player.z=10;s.traffic=s.traffic.slice(0,1);const t=s.traffic[0],x=t.x,z=t.z;let traveled=0;for(let i=0;i<240;i++){const px=t.x,pz=t.z;S.update(s,{},1/60);traveled+=Math.hypot(t.x-px,t.z-pz);}assert(traveled>2,'traffic must advance beyond first frame');assert(Number.isFinite(t.routeProgress));}
 s=S.create();s.traffic=[];s.pedestrians=[];s.player.speed=.6;for(let i=0;i<100;i++){s.paused=false;S.update(s,{s:true},1/60);}assert.equal(s.player.speed,0,'held brake must not reverse');S.update(s,{},1/60);S.update(s,{s:true},1/60);assert(s.player.speed<0,'fresh S press reverses');
 c.load('career');let hubCalls=0,trainingCalls=0;c.PixelSchoolHub={open:({onResult})=>{hubCalls++;onResult({pass:true})}};c.DriveTraining={start:()=>trainingCalls++,active:()=>false};
 s=S.create();s.traffic=[];s.pedestrians=[];S.update(s,{},.01);
 for(const p of W.services){s.player.x=p.x;s.player.z=p.z;s.player.speed=0;assert.equal(S.interact(s).type,'service');if(p.type==='school'){const dialog=c.elements.find(e=>e.className==='career-dialog');const before=c.DriveCareer.credits();dialog.querySelector('#start-quiz').onclick();assert.equal(c.DriveCareer.credits(),before+150);dialog.querySelector('#start-driving').onclick();}}
 assert.equal(hubCalls,1);assert.equal(trainingCalls,2);
 c.load('training');c.DriveTraining.start(s);assert(c.DriveTraining.active());const rampTask=c.DriveTraining.tasks[3];assert.equal(c.DriveTraining.elevation(rampTask.x,rampTask.z),.55);assert(W.roadAt(s.player.x,s.player.z,.1));for(const id of ['seat','mirrors','belt','brake','neutral','clutch','ignition','lights','gear','look','handbrake','go'])c.DriveTraining.clickControl(id);assert(!s.paused);assert.equal(c.DriveTraining.gear(),'1');
 for(const f of ['three.min','surfaces','scenery','maps/building-kit','maps/real-scenery','services'])c.load(f);
 const T=c.THREE,scene=new T.Scene(),windows=[],material=new T.MeshStandardMaterial({color:'#888888'}),materials={road:material,white:material,grass:material};
 const box=(x,y,z,w,h,d,m)=>{const o=new T.Mesh(new T.BoxGeometry(w,h,d),typeof m==='string'?new T.MeshStandardMaterial({color:m}):m);o.position.set(x,y,z);scene.add(o);return o};
 if(W.realMap){
  const joined=new T.Scene(),data={areas:[],buildings:[]},testW={mapData:data,roads:[{type:'residential',surface:'asphalt',width:1,points:[[0,0],[5,0],[5,5]]}],footways:[],nearestRoad:()=>null,serviceSites:[],roadAt:()=>false};
  c.DriveRealScenery.build({W:testW,scene:joined,windows:[]});const pavement=joined.children.filter(o=>o.userData.surface==='pavement');assert.equal(pavement.length,2);
  assert(joined.children.some(o=>o.userData.surface==='marking'),'paved roads have paint');
  const before=pavement[0],after=pavement[1];
  for(const [a,b] of [[2,0],[3,1]]){const pa=new T.Vector3().fromBufferAttribute(before.geometry.attributes.position,a).add(before.position),pb=new T.Vector3().fromBufferAttribute(after.geometry.attributes.position,b).add(after.position);assert(pa.distanceTo(pb)<1e-6,'road bend must share joined edge');assert(Math.abs(before.geometry.attributes.uv.getY(a)-after.geometry.attributes.uv.getY(b))<1e-6,'road texture must remain continuous at bend');}
 }
 c.DriveScenery.build({W,scene,box,materials,windows});const before=scene.children.length;c.DriveServices.build({T,W,scene,box,mat:col=>new T.MeshStandardMaterial({color:col}),materials});assert(scene.children.length-before>200,'detailed services, not plaques');
 let vertices=0;scene.updateMatrixWorld(true);scene.traverse(o=>{if(!o.isMesh)return;const a=o.geometry.attributes.position;vertices+=a.count;for(let i=0;i<a.array.length;i++)assert(Number.isFinite(a.array[i]),'finite geometry');});
 if(W.realMap){const kitScene=new T.Scene();c.DriveBuildingKit.build({T,scene:kitScene,buildings:[{id:6,type:'house',points:[[0,0],[4,0],[4,2],[0,2],[0,0]]}],nearestRoad:()=>({x:2,z:-2}),windows:[]});const roofs=kitScene.children.filter(o=>o.material.map===c.DriveSurfaces.textures.tile&&o.geometry.attributes.position.count>6);assert(roofs.some(o=>{const a=o.geometry.attributes.position;let min=Infinity,max=-Infinity;for(let i=0;i<a.count;i++){min=Math.min(min,a.getY(i));max=Math.max(max,a.getY(i));}return max-min>.2;}),'rectangular footprint roof has raised ridge');}
 if(W.realMap){
  c.load('maps/building-stream');const streamed=new T.Scene(),liveWindows=[],stream=c.DriveBuildingStream.create({T,W,scene:streamed,windows:liveWindows});
  assert.equal(stream.stats().resident,0,'no building geometry at startup');
  const colliderIds=JSON.stringify(W.collisionShapes.map(q=>q.id));
  const visible={intersectsBox:()=>true};let maxResident=0;
  for(const b of W.buildings.filter((_,i)=>i%15===0)){const p=new T.Vector3(b.points[0][0],0,b.points[0][1]);for(let i=0;i<4;i++)stream.update(p,visible);maxResident=Math.max(maxResident,stream.stats().resident);assert(stream.stats().resident<=48);}
  assert(stream.stats().built>10);assert(stream.stats().evicted>0,'distant architecture must be released');
  stream.update(new T.Vector3(-1000,0,-1000),visible);assert.equal(stream.stats().resident,0);assert.equal(liveWindows.length,0);assert.equal(streamed.children.length,0);
  for(let visit=0;visit<3;visit++){const b=W.buildings[0],p=new T.Vector3(b.points[0][0],0,b.points[0][1]);stream.update(p,{intersectsBox:()=>false});assert(stream.stats().resident>0,'nearby solids load even behind camera');stream.update(new T.Vector3(-1000,0,-1000),visible);assert.equal(stream.stats().resident,0);}
  assert.equal(JSON.stringify(W.collisionShapes.map(q=>q.id)),colliderIds,'streaming does not duplicate or remove world solids');
  console.log(JSON.stringify({streaming:stream.stats(),maxResident}));stream.dispose();
  for(const r of W.roads)assert(r.width>=r.sourceWidth&&r.width>=(['track','service'].includes(r.type)?3.5:6.5)*W.mapData.projection.gameUnitsPerMeter);
 }
 if(W.realMap){
  c.load('maps/region-stream');const local=new T.Scene(),art=c.DriveRealScenery.build({W,scene:local,windows:[],deferBuildings:true,stream:true});assert.equal(local.children.length,0,'no environment geometry at startup');assert(art.recipes.length>100);
  const stream=c.DriveRegionStream.create({T,scene:local,recipes:art.recipes}),shown={intersectsBox:()=>true},hidden={intersectsBox:()=>false};
  const start=new T.Vector3(W.playerStart.x,0,W.playerStart.z);for(let i=0;i<20;i++)stream.update(start,[shown]);assert(stream.stats().resident>0);assert(stream.stats().resident<stream.stats().total/3,'only nearby regions loaded');
  stream.update(start,[hidden]);assert(stream.stats().visible>0,'immediate surroundings stay loaded even when looking away');assert(stream.stats().visible<stream.stats().resident,'distant invisible cells remain culled');
  for(const b of W.buildings.filter((_,i)=>i%20===0)){const p=new T.Vector3(b.points[0][0],0,b.points[0][1]);for(let i=0;i<3;i++)stream.update(p,[shown]);assert(stream.stats().resident<=96);}
  stream.update(new T.Vector3(-1000,0,-1000),[shown]);assert.equal(stream.stats().resident,0);assert.equal(local.children.length,0);console.log(JSON.stringify({regions:stream.stats()}));stream.dispose();
 }
 const meshCount=scene.children.length,serviceMeshCount=meshCount-before;
 const chunks=new Map();let oversized=0;scene.updateMatrixWorld(true);for(const o of [...scene.children]){if(!o.isMesh)continue;const bounds=new T.Box3().setFromObject(o),size=bounds.getSize(new T.Vector3());if(size.x>16||size.z>16){oversized++;continue;}const key=Math.floor(o.position.x/8)+','+Math.floor(o.position.z/8)+(W.realMap&&o.userData.detail?':detail':'');if(!chunks.has(key))chunks.set(key,new T.Group());chunks.get(key).add(o);}
 let batched=0;for(const group of chunks.values()){c.DriveScenery.batch(group);batched+=group.children.length;}if(W.realMap)assert.equal(oversized,0,'all map scenery must fit streamer bounds');
 c.load('quiz-bank');for(let i=1;i<=25;i++)c.load('quiz-batches/batch-'+String(i).padStart(2,'0'));assert.equal(c.DriveQuizBank.questions.length,1208);
 console.log(JSON.stringify({city,questions:c.DriveQuizBank.questions.length,chunks:chunks.size,batchedMeshes:batched,oversized,services:W.services.length,meshes:meshCount,serviceMeshes:serviceMeshCount,vertices,checks:'passed'}));
}
