#!/usr/bin/env python3
"""Install only audited Pixel Drive files; refuse unknown local versions."""
import hashlib,json,pathlib,shutil,sys,tempfile
root=pathlib.Path(sys.argv[1]).resolve();source=pathlib.Path(__file__).resolve().parent
manifest=json.loads((source/'manifest.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
conflicts=[]
for name,entry in manifest.items():
 target=(root/name).resolve();payload=(source/name).resolve()
 if not target.is_relative_to(root) or not payload.is_relative_to(source):raise SystemExit('Invalid package path')
 if sha(payload)!=entry['sha256']:raise SystemExit('Package checksum failed: '+name)
 if target.exists() and sha(target) not in entry['allowed']:conflicts.append(name)
if conflicts:raise SystemExit('No files changed. Conflicting edits require merging:\n'+'\n'.join(conflicts))
backup=pathlib.Path(tempfile.mkdtemp(prefix='pixel-drive-before-v53-'))
for name,entry in manifest.items():
 target=root/name
 if target.exists():
  saved=backup/name;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,saved)
 target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/name,target)
print('Installed',len(manifest),'files. Backup:',backup)
