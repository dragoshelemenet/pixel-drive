Pixel Drive Quiz Fix v3 (v36)

Only four files are included, under dist/nivel-1/. The rest of the existing game is untouched.

Fixes:
- Countdown element exists directly in level HTML and remains visible in all HUD modes, including 3D cockpit.
- Timer follows actual active elapsed time even at low frame rates and when the vehicle is stopped.
- Timer/popup works while driving in the driving-school training mode (after starting the engine).
- Game explicitly registers its state with the quiz timer at initial load and after a restart.
- ?quizTest=1 reveals TEST ACUM and uses 10 seconds instead of 120.
- Existing image questions and fallback assets remain unchanged; v2 files must already be present.

Codespaces terminal after uploading ZIP to repository root:
  git pull
  unzip -o Pixel-Drive-Quiz-Fix-v3.zip -d .
  git add dist/nivel-1/index.html dist/nivel-1/timed-quiz.js dist/nivel-1/joc.js dist/nivel-1/drive.css
  git commit -m 'Fix quiz HUD and timer in 3D driving'
  git push origin main
  python3 -m http.server 8000 --bind 0.0.0.0 --directory dist

Open forwarded port /nivel-1/?quizTest=1, not just /.
Do not extract original Pixel-Drive.zip AFTER applying this patch (would revert level HTML etc).
